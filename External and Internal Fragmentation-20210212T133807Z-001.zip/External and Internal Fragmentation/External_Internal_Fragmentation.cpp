//External & Internal Fragmentation
//Name-Noel Varghese
//Reg No-19BCY10005
#include<iostream>
using namespace std;
int main()
{
int n,i,j,b[20],sb[20],t[20],x,c[20][20],d[20],a[20][20],sb2[20],q[20],fragmentation_file_1=0,fragmentation_file_2=0;
int data=0,slots_occupied=0;
int slots_occupied_2=0,data2=0,start_block=0,start_block_2=0;
cout<<"Enter number of files = ";
cin>>n;                               //Maximum files=2
for(i=0;i<1;i++)
{
if(n==1)
{
cout<<"Enter no. of blocks occupied by file"<<" "<<i+1<<" = ";  //Array slots to be allocated to file
cin>>b[i];
data=b[i];
cout<<"Enter the starting block of file"<<" "<<i+1<<" = ";     //Starting Block=Slot from where you want to start entering data
cin>>sb[i];
t[i]=sb[i];
for(j=0;j<b[i];j++)
c[i][j]=sb[i]++;
start_block=t[i];
}
else if(n==2)
{
cout<<"Enter no. of blocks occupied by file"<<" "<<i<<" = ";  //Array slots to be allocated to file
cin>>b[i];
data=b[i];
cout<<"Enter the starting block of file"<<" "<<i<<" = ";  //Starting Block=Slot from where you want to start entering data
cin>>sb[i];
t[i]=sb[i];
start_block=t[i];
for(j=0;j<b[i];j++)
c[i][j]=sb[i]++;
cout<<"Enter no. of blocks occupied by file"<<" "<<i+1<<" = ";
cin>>d[i];
data2=d[i];
cout<<"Enter the starting block of file "<<" "<<i+1<<" = ";
cin>>sb2[i];
q[i]=sb2[i];
start_block_2=q[i];
for(j=0;j<d[i];j++)
a[i][j]=sb2[i]++;
}
}
cout<<"Display File Allocation"<<endl;
if(n==1)
{
cout<<"File Number   Start block    Length"<<endl;
for(i=0;i<n;i++)
{
cout<<i<<"              "<<t[i]<<"                "<<b[i]<<endl;
}
}
else if(n==2)
{
cout<<"File Number   Start block    Length"<<endl;
for(i=0;i<1;i++)
{
cout<<"1"<<"              "<<t[i]<<"                "<<b[i]<<endl;
cout<<"2"<<"              "<<q[i]<<"                "<<d[i]<<endl;
}
}
else
{
cout<<"Invalid"<<endl;
}
cout<<"User has to enter data into file"<<endl;
if(n==1)
{
cout<<"Enter the number of array slots you want to fill"<<endl;
cin>>slots_occupied;
}
else if(n==2)
{
cout<<"Enter the number of array slots to be filled for File 1"<<endl;
cin>>slots_occupied;
cout<<"Enter the slot count for the File 2"<<endl;
cin>>slots_occupied_2;
}
else
{
cout<<"Invalid"<<endl;
}
if(n==1)
{
cout<<"Enter data into File 1"<<endl; //Contigious File Allocation is followed here
for(i=0;i<slots_occupied;i++)
{
cin>>b[i];
}
cout<<"File Number   Fragmentation"<<endl;
for(i=0;i<n;i++)
{
fragmentation_file_1=data-slots_occupied-start_block;
cout<<i<<"               "<<fragmentation_file_1<<endl;
}
}
else if(n==2)
{
cout<<"Enter data into File array 1"<<endl;
for(i=0;i<slots_occupied;i++)
{
cin>>b[i];                     //Contigious File Allocation is followed here
}
cout<<"Enter data into File array 2"<<endl;
for(i=0;i<slots_occupied_2;i++)
{
cin>>d[i];                  //Contigious File Allocation is followed here
}
cout<<"File Number   Fragmentation"<<endl;
for(i=0;i<n;i++)
{
fragmentation_file_1=data-slots_occupied-start_block;
fragmentation_file_2=data2-slots_occupied_2-start_block_2;
}
cout<<"0"<<"               "<<fragmentation_file_1<<endl;
cout<<"1"<<"               "<<fragmentation_file_2<<endl;
}
return 0;
}
